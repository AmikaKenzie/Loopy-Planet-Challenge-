﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoopyChallenge
{
    class Program
    {
        static void Main(string[] args)
        {
            int Menu_Planets;
            double weight;

            string myName;
            Console.WriteLine("Please enter your name");
            myName = Console.ReadLine();

            do
            {

                Console.Write("\n\n");
                Console.WriteLine("           Menu of Planets          ");
                Console.WriteLine("           ==== == =======          ");
                Console.WriteLine("1. Jupiter    2. Mars     3. Mercury");
                Console.WriteLine("4. Neptune    5. Pluto    6. Saturn ");
                Console.WriteLine("7. Uranus     8. Venus    9. <Quit> ");
                Console.Write("\n\n");

                // Get user input
                Console.WriteLine("Enter weight on earth");
                weight = Convert.ToDouble(Console.ReadLine());//YOU HAD STRING INPUT HERE
                Console.WriteLine();                             // CHANGED TO DOUBLE
                Console.WriteLine("\nSelect Menu Choice");
                Menu_Planets = Convert.ToInt32(Console.ReadLine());

                //Switch statements to execute different Menu_Planets
                switch (Menu_Planets)
                {
                    case 1:     //Jupiter
                        Console.WriteLine("Your weight of " + weight + " pounds on Earth would be " + 2.64 * weight + " pounds on Jupiter\n"); //Multiplies weight by
                        break;

                    case 2:     //Mars
                        Console.WriteLine("Your weight of " + weight + " pounds on Earth would be " + 0.38 * weight + " pounds on Mars\n");
                        break;

                    case 3:     //Mercury
                        Console.WriteLine("Your weight of " + weight + " pounds on Earth would be " + 0.37 * weight + " pounds on Mercury");
                        break;

                    case 4:     //Neptune
                        Console.WriteLine("Your weight of " + weight + " pounds on Earth would be " + 1.12 * weight + " pounds on Neptune\n");
                        break;

                    case 5:     //Pluto
                        Console.WriteLine("Your weight of " + weight + " pounds on Earth would be " + 0.04 * weight + " pounds on Pluto\n");
                        break;

                    case 6:     //Saturn
                        Console.WriteLine("Your weight of " + weight + " pounds on Earth would be " + 1.15 * weight + " pounds on Saturn\n");
                        break;

                    case 7:     //Uranus
                        Console.WriteLine("Your weight of " + weight + " pounds on Earth would be " + 1.15 * weight + " pounds on Uranus\n");
                        break;

                    case 8:     //Venus
                        Console.WriteLine("Your weight of " + weight + " pounds on Earth would be " + 0.88 * weight + " pounds on Venus\n");
                        break;


                    case 9:
                        Console.WriteLine("Have a Nice Day. GoodBye\n");
                        break;

                    default:
                        Console.WriteLine("You entered an invalid number. Choose from 1-8 only.\n");
                        Console.WriteLine("Enter a choice from 1-9: ");
                        break;
                }
            } while (Menu_Planets != 9);
        }
    }
}



